V3.9
- Abwesenheitszeiträume pro Spieler
- automatische Abmeldung in Trainings, Spielen und Trainingslagern
- Grund sichtbar
- neue Termine werden automatisch geprüft
- nur index.html in GitHub ersetzen
